# To run the code, run the command below with your respective links from the CLI
# python chi.py --stopwords path/to/stopwords.txt -r hadoop --hadoop-streaming-jar /usr/lib/hadoop/tools/lib/hadoop-streaming-3.3.5.jar path/to/dataset > output.txt

from mrjob.job import MRJob
from mrjob.step import MRStep
import pandas as pd
import json
import re

class ChiMR(MRJob):

    # Parametrize links
    def configure_args(self):
        super(ChiMR, self).configure_args()
        self.add_file_arg('--stopwords', help='Path to the stopwords file')

    # Define MR Steps
    def steps(self):
        return [
            MRStep(mapper_init=self.mapperInit,
                   mapper=self.mapper,
                   combiner=self.combiner,
                   reducer=self.reducerA),
            MRStep(reducer=self.reducerB)
        ]

    def mapperInit(self):
        # Load stopwords from the local copy distributed to each node
        with open(self.options.stopwords, 'r') as file:
            self.stopwords = set(line.strip() for line in file)

        # Regex pattern for splitting the reviews
        self.pattern = re.compile(r'[\s\t\d\(\)\[\]\{\}\.!\?,;:+=\-_"\'`~#@&\*%€$§\\/]+')

    def mapper(self, _, line):
        # Load the JSON object - this loads the dataset
        json_line = json.loads(line)

        # Extract the review and category and perform case folding on them
        review_text = json_line.get('reviewText', '').lower()
        category = json_line.get('category', '').lower()

        # Tokenization using the compiled pattern
        words = self.pattern.split(review_text)

        # Stopword filtering and emit key-value pairs
        for word in words:
            if len(word) > 1 and word not in self.stopwords:
                yield (category, word), 1

    # Sum up the key-value pairs on each node so the reducing phase goes faster
    def combiner(self, key, values):
        yield key, sum(values)

    # Sum up the key-value pairs and emit as a list of key - value pairs
    def reducerA(self, key, values):
        # Accumulate the values into a list
        yield None, (key, sum(values))

    # Calculate chi-square values, sort-filter and write output.txt
    def reducerB(self, _, values):
        # Convert list key-value pairs to a DataFrame
        data = list(values)
        df = pd.DataFrame(data, columns=['Key', 'A'])
        df[['Category', 'Word']] = pd.DataFrame(df['Key'].tolist(), index=df.index)
        df.drop('Key', axis=1, inplace=True)

        # Set 'N' to the total sum of all 'A' entries (sum of sums of key-values pairs)
        N = df['A'].sum()

        # ----> B value
        # Sum every occurrence of a word across all categories
        # And reduce it by all occurrences of the word in the current category (A)
        df['B'] = df.groupby('Word')['A'].transform('sum') - df['A']

        # ----> C value
        # Calculate the sum of all words within the same category
        # And reduce it by all occurrences of the word in the current category (A)
        df['C'] = df.groupby('Category')['A'].transform('sum') - df['A']

        # ----> D value --> D = N - (A + B + C)
        # number of words not in the current word's category without the current word
        df['D'] = N - (df['A'] + df['B'] + df['C'])

        # Compute 'chi_squared' for each row according to the formula from Lecture 3 - slide No.39
        df['chi_squared'] = N * ((df['A'] * df['D'] - df['B'] * df['C']) ** 2) / (
            (df['A'] + df['B']) * (df['A'] + df['C']) * (df['B'] + df['D']) * (df['C'] + df['D']))

        # Select top 75 words for each category based on Chi-Squared
        df = df.sort_values(['Category', 'chi_squared'], ascending=[True, False])
        top_75 = df.groupby('Category').head(75)

        # Creating a sorted list of all unique terms
        all_words = ' '.join(sorted(df['Word'].unique()))
        
        # Yield top 75 words grouped by category, with ascending chi-square values (categories sorted alphabettically)
        for category, group in top_75.groupby('Category'):
            words_string = ' '.join(f"{row['Word']}:{row['chi_squared']:.2f}" for _, row in group.iterrows())
            yield f"<{category}>", words_string
        yield "", all_words # Yield a single line containing all unique words, sorted alphabetically space separated
   
if __name__ == '__main__':
    ChiMR.run()
